from PyQt5 import QtWidgets, QtGui, QtCore
from resume_parser import parse_resume
import sys

class ResumeParserApp(QtWidgets.QWidget):
    def __init__(self, vectorizer, model):
        super().__init__()
        self.vectorizer = vectorizer
        self.model = model
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("AI Resume Parser")
        self.setGeometry(100, 100, 800, 600)
        layout = QtWidgets.QVBoxLayout()

        # Drag-and-Drop area
        self.drop_area = QtWidgets.QLabel("Drag and Drop Resume PDF Here", self)
        self.drop_area.setAlignment(QtCore.Qt.AlignCenter)
        self.drop_area.setStyleSheet("border: 2px dashed #aaa; padding: 50px;")
        layout.addWidget(self.drop_area)

        # Set filters (skills, experience, etc.)
        self.skills_input = QtWidgets.QLineEdit(self)
        self.skills_input.setPlaceholderText("Enter required skills (comma-separated)")
        layout.addWidget(self.skills_input)

        self.age_slider = QtWidgets.QSlider(QtCore.Qt.Horizontal, self)
        self.age_slider.setRange(20, 60)
        self.age_slider.setValue(30)
        layout.addWidget(self.age_slider)

        # Results area
        self.results_area = QtWidgets.QTextEdit(self)
        self.results_area.setReadOnly(True)
        layout.addWidget(self.results_area)

        # "Next Resume" button to clear previous results and accept new file
        self.next_button = QtWidgets.QPushButton("Next Resume", self)
        self.next_button.clicked.connect(self.clear_results)
        layout.addWidget(self.next_button)

        # Set layout
        self.setLayout(layout)
        self.show()

        # Enable drag and drop
        self.setAcceptDrops(True)

        # Initialize variables
        self.current_file_path = ""

    def dragEnterEvent(self, event):
        # Allow drop only for PDF files
        if event.mimeData().hasUrls():
            url = event.mimeData().urls()[0].toLocalFile()
            if url.endswith('.pdf'):
                event.acceptProposedAction()
            else:
                event.ignore()
        else:
            event.ignore()

    def dropEvent(self, event):
        # Get the file path and parse the resume
        self.current_file_path = event.mimeData().urls()[0].toLocalFile()
        self.parse_and_display(self.current_file_path)

    def parse_and_display(self, file_path):
        # Parse resume and get results (score, skills, etc.)
        score, skills_found = parse_resume(file_path, self.vectorizer, self.model)

        # Display the score
        result_text = f"Resume Score: {score}\n\n"

        # Get required skills from input
        required_skills = [skill.strip().lower() for skill in self.skills_input.text().split(",")]

        # Display skills found and matching skills
        matched_skills = [skill for skill in skills_found if skill.lower() in required_skills]
        unmatched_skills = [skill for skill in skills_found if skill.lower() not in required_skills]

        result_text += f"Skills Found: {', '.join(skills_found)}\n"
        result_text += f"Skills Matching Input: {', '.join(matched_skills)}\n"
        result_text += f"Skills Not Matching: {', '.join(unmatched_skills)}\n"

        # Display the results in the results area
        self.results_area.setText(result_text)


    def clear_results(self):
        # Clear previous results and allow the user to upload a new resume
        self.results_area.clear()
        self.skills_input.clear()
        self.current_file_path = ""
        self.skills_input.setPlaceholderText("Enter required skills (comma-separated)")

def main_gui(vectorizer, model):
    app = QtWidgets.QApplication(sys.argv)
    window = ResumeParserApp(vectorizer, model)
    sys.exit(app.exec_())
