from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
import numpy as np

def train_model(data):
    vectorizer = TfidfVectorizer(max_features=5000)
    X = vectorizer.fit_transform(data)
    kmeans = KMeans(n_clusters=10, random_state=42)
    kmeans.fit(X)
    return vectorizer, kmeans

def score_resume(vectorizer, model, resume_text):
    vector = vectorizer.transform([resume_text])
    score = np.max(model.transform(vector))
    return 10 - score  # Higher score is better
