import pandas as pd
from model import train_model
from gui import main_gui
from preprocessing import preprocess_text

# Load and preprocess data
data = pd.read_csv("UpdatedResumeDataSet.csv")

# Avoid circular import by moving the import inside the function
def load_and_process_data():
    preprocessed_resumes = data["Resume"].apply(preprocess_text)
    return preprocessed_resumes

# Train model
preprocessed_resumes = load_and_process_data()
vectorizer, model = train_model(preprocessed_resumes)

# Launch GUI
main_gui(vectorizer, model)
