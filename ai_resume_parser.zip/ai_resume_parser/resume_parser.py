from preprocessing import preprocess_text
from model import score_resume
import PyPDF2

def extract_text_from_pdf(pdf_path):
    with open(pdf_path, "rb") as file:
        reader = PyPDF2.PdfReader(file)
        text = ""
        for page in reader.pages:
            text += page.extract_text()
        return text

def parse_resume(pdf_path, vectorizer, model):
    # Extract and preprocess the text from the resume PDF
    text = extract_text_from_pdf(pdf_path)
    preprocessed_text = preprocess_text(text)

    # Get the resume score (use the model to score it)
    score = score_resume(vectorizer, model, preprocessed_text)

    # Extract skills from the resume
    skills_found = extract_skills_from_resume(preprocessed_text)

    # Return both the score and the list of skills found
    return score, skills_found

def extract_skills_from_resume(text):
    # Example: Simple skills extraction based on a predefined list
    predefined_skills = ['python', 'java', 'sql', 'data science', 'machine learning', 'javascript', 'html', 'css']
    found_skills = [skill for skill in predefined_skills if skill in text.lower()]
    return found_skills


def extract_skills_from_resume(text):
    # A simple example of skills extraction (replace this with actual logic)
    predefined_skills = ['python', 'java', 'sql', 'data science', 'machine learning', 'javascript', 'html', 'css']
    found_skills = [skill for skill in predefined_skills if skill in text.lower()]
    return found_skills
